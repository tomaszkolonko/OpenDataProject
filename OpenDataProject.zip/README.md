# OpenDataProject
Gemeinde Finanzierung Zürich

## Set up
Clone the repository into your folder. Open page.html in browser.

## Explanation
D3.js relevant files are in d3 folder.
Data is in comma seperated format and is within the root.